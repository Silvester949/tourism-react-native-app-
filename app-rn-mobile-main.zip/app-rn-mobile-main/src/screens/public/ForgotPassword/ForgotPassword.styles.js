import { StyleSheet } from 'react-native';

const makeStyles = (theme) =>
  StyleSheet.create({
    container: {
      flex: 1,
      flexDirection: 'column',
    },
  });

export default makeStyles;
