import {StyleSheet} from 'react-native';
import {blue_5, gray_4, gray_9} from '../../../styles/colors';

const makeStyles = theme =>
  StyleSheet.create({
    tPassword: {
      marginTop: 5,
    },
  });

export default makeStyles;
