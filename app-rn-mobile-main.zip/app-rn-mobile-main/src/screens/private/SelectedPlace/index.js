export { SelectedPlace } from './SelectedPlace.screen';
