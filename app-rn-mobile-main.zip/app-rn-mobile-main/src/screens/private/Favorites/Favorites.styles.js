import {StyleSheet} from 'react-native';
import {gray_1, gray_9} from '../../../styles/colors';

const makeStyles = theme =>
  StyleSheet.create({
    container: {
      backgroundColor: gray_1,
    },
  });

export default makeStyles;
