export { SelectedPlaceCard } from './SelectedPlaceCard.component';
