export { BottomTabBar } from './BottomTabBar.component';
