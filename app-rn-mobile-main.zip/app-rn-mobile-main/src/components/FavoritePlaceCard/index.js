export { FavoritePlaceCard } from './FavoritePlaceCard.component';
